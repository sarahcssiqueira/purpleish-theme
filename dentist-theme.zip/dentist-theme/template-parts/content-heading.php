<?php
/**
 * Template part for displaying banner section.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 */

?>

<div class="heading">
      <div class="container">      
            <section>
              <h1>
                <?php echo get_bloginfo('description'); ?>
              </h1>
            </section>

      </div>
</div>