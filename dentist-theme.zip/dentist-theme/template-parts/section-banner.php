<?php
/**
 * Template part for displaying a banner section.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 */

?>
<div class="banner">
      <div class="innerSectionLarge">      
            <section>
              <h1>
              </h1>
            </section>
      </div>
</div>