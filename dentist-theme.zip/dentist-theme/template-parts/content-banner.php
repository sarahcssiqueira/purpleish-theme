<?php
/**
 * Template part for displaying banner section.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 */

?>

<div class="banner">
      <div class="container">      
            <section>
              <h1>
              </h1>
            </section>
          
       
      </div>
</div>